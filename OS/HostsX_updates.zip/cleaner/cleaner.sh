#!/system/bin/sh

# read delete-list and remove
for file in $(cat /tmp/delete-list.txt)
do
  rm -f $file
done


# clean up empty directories
rm -rf /system/media/video

